# Nexus Design

The shared design system for our products (Deploy, SSO, …), built on **Mantine 9**.
Nord-inspired: white and cool-gray surfaces, a calm blue primary, Polar-Night dark mode,
short eased-out motion.

```
packages/design   @nexus/design – theme, tokens, global CSS, shared components and hooks
apps/playground   docs-style playground: one page per component (all of Mantine 9 + Nexus)
```

The playground mirrors mantine.dev: every Mantine 9 component, all 22 chart types, dates, extensions
(carousel, rich text editor, schedule, spotlight, dropzone…), `@mantine/form` and every `@mantine/hooks` hook get
their own page, alongside the Nexus components and full example screens. Each page shows the import line, the Nexus
defaults applied to that component, a live props configurator and focused demos with code.

Adding a page: create `apps/playground/src/docs/<category>/<name>.tsx` exporting `meta` and a default component –
it is picked up automatically (files starting with `_` are treated as helpers).

## Run the playground

```bash
npm install
npm run dev          # http://localhost:5180
```

`⌘K` searches the playground, `⌘.` opens the theme settings (color scheme, primary color, radius, scale).

## Use it in a project

```bash
npm install @nexus/design @mantine/core@^9.7 @mantine/hooks@^9.7 @mantine/modals@^9.7
# optional, as needed:
npm install @mantine/notifications @mantine/dates dayjs @mantine/charts recharts @mantine/code-highlight @mantine/spotlight
```

Import Mantine's **layered** styles first, then Nexus. (Layered CSS lets Nexus override Mantine without specificity fights.)

```tsx
import '@mantine/core/styles.layer.css';
import '@mantine/notifications/styles.layer.css'; // + any other @mantine/* you use
import '@nexus/design/styles.css';                 // also loads Geist + Geist Mono

import { ModalsProvider } from '@mantine/modals';
import { Notifications } from '@mantine/notifications';
import { NexusProvider, notificationsDefaults } from '@nexus/design';

export function Root() {
  return (
    <NexusProvider>                      {/* defaultColorScheme="auto" */}
      <ModalsProvider>
        <Notifications {...notificationsDefaults} />
        <App />
      </ModalsProvider>
    </NexusProvider>
  );
}
```

Per-product tweaks go through the `theme` prop and are merged on top of the Nexus theme:

```tsx
<NexusProvider theme={{ primaryColor: 'teal' }}>…</NexusProvider>
```

For SSR, render `<ColorSchemeScript defaultColorScheme="auto" />` in `<head>` and spread `mantineHtmlProps` on `<html>`, as with plain Mantine.

## What's in the package

| Export | What it is |
| --- | --- |
| `theme` | The Mantine theme override (colors, type, radius, spacing, shadows, component defaults). |
| `cssVariablesResolver` | Adds the `--nx-*` semantic tokens and Nexus surface layering. Already applied by `NexusProvider`. |
| `colors`, `nord`, `semanticColors`, `chartSeries` | Palettes, the original Nord values, intent → color aliases, ordered chart series. |
| `fonts`, `motion`, `shadows`, `radius`, `spacing` | Raw tokens for use in JS. |
| `NexusProvider` | `MantineProvider` preconfigured with the theme. |
| **Page structure** | `PageHeader` (eyebrow, meta, tabs, hero), `SectionHeader`, `SectionCard` (flush, scroll, danger, loading), `ResourceCard`, `PageHeaderSkeleton`, `TableSkeleton`, `CardSkeleton`, `FormSkeleton` |
| **App shell** | `SidebarNav` (data-driven, permission filtering with `*:*` wildcards), `AppHeaderBar`, `UserChip`, `UserMenu`, `ColorSchemeToggle` |
| **Status** | `statusTones` / `createStatusMap` / `StatusMapProvider` (one status vocabulary for Deploy and SSO), `StatusBadge`, `StatusDot`, `StatusIcon`, `StepTrack`, `RelativeTime`, `ExpiryBadge`, `thresholdColor` |
| **Metrics** | `StatCard`, `StatGroup`, `MetricRow`, `MeterBar`, `GaugeTile`, `SparkBars`, `Legend` |
| **Logs** | `LogViewer` (streams, search, wrap, stick-to-bottom), `useStickToBottom` |
| **Forms & actions** | `CopyField`, `SecretReveal`, `MetaChip`, `SearchInput`, `RefreshButton`, `SettingRow` / `SettingsList`, `ImageField`, `InlineEditableText`, `confirmAction` / `ConfirmButton` |
| **Editors** | `ListEditor`, `KeyValueEditor` (+ `.env` paste), `PortMappingEditor`, `CheckboxMatrix` |
| **Auth** | `AuthLayout`, `AuthCard`, `ProviderButtons`, `OtpStep` |
| **Launcher** | `AppTile`, `AppTileGrid`, `colorFromName`, `initialsFromName` |
| **Hooks** | `useRowSelection`, `usePolling`, `useAsyncAction`, `useKeyedAsyncAction`, `useAutoCycle`, `useStableList` |
| **Formatters** | `formatBytes`, `formatPercent`, `formatDuration`, `formatRelativeTime`, `formatDateTime`, `formatCount`, `formatNumberCompact` |
| `@nexus/design/styles.css` | Fonts, focus ring, transitions, surface/border tweaks, Nord syntax highlighting, utility classes. |

### Semantic CSS variables

Prefer these over raw palette values in app CSS; they switch with the color scheme.

| Variable | Light | Dark |
| --- | --- | --- |
| `--nx-color-canvas` | gray.0 | dark.8 |
| `--nx-color-surface` | white | dark.7 |
| `--nx-color-surface-raised` | white | dark.6 |
| `--nx-color-surface-sunken` / `-hover` | gray.1 | dark.8 / dark.6 |
| `--nx-color-border` / `-strong` | gray.2 / gray.3 | dark.5 / dark.4 |
| `--nx-color-text` / `-muted` / `-subtle` | Nord 0 / gray.6 / gray.5 | dark.0 / dark.2 / dark.3 |
| `--nx-color-accent` / `-accent-soft` / `-focus` | blue.6 / blue.0 / blue.5 | blue.4 / tint / blue.4 |
| `--nx-duration-{instant,fast,base,slow}` | 80 / 120 / 180 / 260 ms | |
| `--nx-ease-{out,in,in-out}` | | |

### Utility classes

- `nx-interactive`: a card that lifts slightly on hover (for clickable cards).
- `nx-fade-in`: fades content in on mount. `nx-stagger` does the same for each child, one after another.
- `nx-tabular`: tabular numbers.
- `nx-hover`: hover background for rows built from `UnstyledButton` (account switchers, user menus).
- `nx-table-scroll`: cap a `Table.ScrollContainer` at `--nx-table-scroll-max` (28rem) with a visible scrollbar. Prefer `SectionCard scroll` when the table lives in a card.

All animations respect `prefers-reduced-motion`.

## Design decisions

- **Color.** Every Mantine color key is overridden with a 10-shade OKLCH scale derived from Nord.
  Each Nord hue sits around shades 4–5. Shade 6 (the primary shade) is deepened so white text on it passes WCAG AA.
  The dark scheme uses Nord Polar Night (`dark.0` = `#D8DEE9`, `dark.6` ≈ `#2E3440`).
- **Surfaces.** The page canvas sits one step below cards in both schemes. In dark mode, borders show elevation instead of shadows.
- **Light variant in dark mode.** Mantine 9's default (`darken(shade 9)`) looks muddy on Polar Night.
  Nexus uses a translucent shade-5 tint with shade-3 text instead.
- **Type.** Geist and Geist Mono (already used by Deploy and SSO). The base size is 15px. Headings are weight 600, with slightly negative tracking.
- **Defaults.** Badges use sentence case and the light variant. ActionIcons are subtle and gray. Cards have a border, a large radius and an xs shadow.
  Inputs show a soft focus halo. Popovers and menus "pop" in over 120ms.

## Build

```bash
npm run build -w @nexus/design   # dist/: ESM + CJS + .d.ts + styles.css
npm run typecheck -w @nexus/design
npm run verify:release-artifact -w @nexus/design
```

During development the workspace consumes `src/` directly. On publish, `publishConfig` points the exports at `dist/`.
`verify:release-artifact` stages the same manifest shape used for GitHub Packages,
creates a local npm tarball, unpacks it outside the checkout, and smoke-tests its
ESM/CommonJS exports and CSS entries against installed React/Mantine peer dependencies.
It does not publish. Run it before the separate, deliberate release step.
